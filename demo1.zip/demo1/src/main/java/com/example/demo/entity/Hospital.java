package com.example.demo.entity;

import javax.persistence.*;

@Entity
@Table(name = "doctors")
public class Hospital {
}

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hospitalid")
    private int hospitalId;
    @Column(name = "name")
    private String name;
    @Column(name = "add")
    private String add;

    @Column(name = "tel")
    private String tel;

    public int getHospitalId() {
        return hospitalId;
    }

    public void setHospitalId(int hospitalId) {
        this.hospitalId = hospitalId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }
}
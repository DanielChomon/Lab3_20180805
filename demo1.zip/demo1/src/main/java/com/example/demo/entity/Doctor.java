package com.example.demo.entity;

import javax.persistence.*;

@Entity
@Table(name = "doctors")
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "doctorid")
    private int doctorId;
    @Column(name = "hospitalname", nullable = false)
    private String hospitalName;
    @Column(name = "name")
    private String name;
    @Column(name = "specialty")
    private String specialty;

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public String getHospitalname() {
        return hospitalName;
    }

    public void setHospitalname(String hospitalname) {
        this.hospitalName = hospitalname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }
}